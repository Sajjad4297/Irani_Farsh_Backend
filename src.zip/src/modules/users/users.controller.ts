import { Controller, Get, Post, Body, Patch, Param, Delete, Put, UseInterceptors, UseGuards } from '@nestjs/common';
import { UsersService } from './users.service';
import { RegisterUserDto } from './dto/register-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { LoginUserDto } from './dto/login-user.dto';
import { Files } from 'src/common/decorators/files.decorator';
import { FastifyFileInterceptor } from 'src/common/interceptors/fastify-file.interceptor';
import { UserAuthGuard } from 'src/common/guards/user-auth.guard';
import { User } from 'src/common/decorators/user.decorator';
import { AuthAttemptLogInterceptor } from 'src/common/interceptors/auth-attempt-log.interceptor';
import { ImageValidationPipe } from 'src/common/pipes/image-validation.pipe';

@Controller('users')
export class UsersController {
    constructor(private readonly usersService: UsersService) { }

    @UseInterceptors(AuthAttemptLogInterceptor)
    @Post('register')
    login(@Body() registerUserDto: RegisterUserDto) {
        return this.usersService.register(registerUserDto);
    }

    @UseInterceptors(AuthAttemptLogInterceptor)
    @Post('login')
    register(@Body() loginUserDto: LoginUserDto) {
        return this.usersService.login(loginUserDto);
    }


    @Get()
    findAll() {
        return this.usersService.findAll();
    }

    @Put('profileImage')
    @UseGuards(UserAuthGuard)
    @UseInterceptors(FastifyFileInterceptor)
    updateProfile(@User() user, @Files(ImageValidationPipe) file) {
        return this.usersService.updateProfile(user, file);
    }

    @Put()
    @UseGuards(UserAuthGuard)
    update(@Body() updateUserDto: UpdateUserDto, @User() user) {
        return this.usersService.update(updateUserDto, user);
    }
    @Get('info')
    @UseGuards(UserAuthGuard)
    findUserInfo(@User() user) {
        return this.usersService.findUserInfo(user);
    }

}
